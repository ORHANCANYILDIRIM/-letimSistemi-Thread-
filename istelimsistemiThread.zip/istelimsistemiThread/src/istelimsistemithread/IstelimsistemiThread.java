import java.util.ArrayList;
import java.util.List;

public class IstelimsistemiThread {
    public static void main(String[] args) {
        // 1'den 1.000.000'e kadar olan sayıları içeren ArrayList'i oluştur
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 1000; i++) {
            numbers.add(i);
        }

        List<Integer> Ciftnumbers = new ArrayList<>();
        List<Integer> Teknumbers = new ArrayList<>();
        List<Integer> Asalnumbers = new ArrayList<>();

        // Oluşturulan ArrayList'i 4 eşit parçaya ayır
        List<List<Integer>> dividedList = new ArrayList<>();
        int chunkSize = numbers.size() / 4;
        int startIndex = 0;

        for (int i = 0; i < 4; i++) {
            List<Integer> chunk = numbers.subList(startIndex, startIndex + chunkSize);
            dividedList.add(chunk);
            startIndex += chunkSize;
        }
        List<Integer> parca1 = dividedList.get(0);
        List<Integer> parca2 = dividedList.get(1);
        List<Integer> parca3 = dividedList.get(2);
        List<Integer> parca4 = dividedList.get(3);

        Thread t1 = new Thread() {
            @Override
            public void run() {
                for (Integer num : parca1) {
                    if (num % 2 == 0) {
                        synchronized (Ciftnumbers) {
                            Ciftnumbers.add(num);
                        }
                    } else {
                        synchronized (Teknumbers) {
                            Teknumbers.add(num);
                        }
                    }
                    if (isAsal(num)) {
                        synchronized (Asalnumbers) {
                            Asalnumbers.add(num);
                        }
                    }
                }
            }
        };

        Thread t2 = new Thread() {
            @Override
            public void run() {
                  for (Integer num : parca2) {
                    if (num % 2 == 0) {
                        synchronized (Ciftnumbers) {
                            Ciftnumbers.add(num);
                        }
                    } else {
                        synchronized (Teknumbers) {
                            Teknumbers.add(num);
                        }
                    }
                    if (isAsal(num)) {
                        synchronized (Asalnumbers) {
                            Asalnumbers.add(num);
                        }
                    }
                }
            }
        };

        Thread t3 = new Thread() {
            @Override
            public void run() {
                    for (Integer num : parca3) {
                    if (num % 2 == 0) {
                        synchronized (Ciftnumbers) {
                            Ciftnumbers.add(num);
                        }
                    } else {
                        synchronized (Teknumbers) {
                            Teknumbers.add(num);
                        }
                    }
                    if (isAsal(num)) {
                        synchronized (Asalnumbers) {
                            Asalnumbers.add(num);
                        }
                    }
                }
            }
        };

        Thread t4 = new Thread() {
            @Override
            public void run() {
                     for (Integer num : parca4) {
                    if (num % 2 == 0) {
                        synchronized (Ciftnumbers) {
                            Ciftnumbers.add(num);
                        }
                    } else {
                        synchronized (Teknumbers) {
                            Teknumbers.add(num);
                        }
                    }
                    if (isAsal(num)) {
                        synchronized (Asalnumbers) {
                            Asalnumbers.add(num);
                        }
                    }
                }
            }
        };

        t1.start();
        t2.start();
        t3.start();
        t4.start();

        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Sonuçları yazdır
        System.out.println("Çift Sayılar: " + Ciftnumbers);
        System.out.println("Tek Sayılar: " + Teknumbers);
        System.out.println("Asal Sayılar: " + Asalnumbers);
        
    }

    private static boolean isAsal(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

}
